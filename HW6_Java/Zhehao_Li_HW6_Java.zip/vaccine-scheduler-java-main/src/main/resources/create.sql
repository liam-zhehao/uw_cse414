CREATE TABLE Caregivers (
    Username varchar(255),
    Salt BINARY(16),
    Hash BINARY(16),
    PRIMARY KEY (Username)
);

CREATE TABLE Availabilities (
    Time date,
    Username varchar(255) REFERENCES Caregivers NOT NULL,
    PRIMARY KEY (Time, Username)
);

CREATE TABLE Vaccines (
    Name varchar(255),
    Doses int,
    PRIMARY KEY (Name)
);

CREATE TABLE Patients (
    Username varchar(255),
    Salt BINARY(16),
    Hash BINARY(16),
    PRIMARY KEY (Username)
);

CREATE TABLE Appointments (
    ID int PRIMARY KEY,
    Date DATE,
    Caregiver varchar(255) REFERENCES Caregivers NOT NULL,
    Patient varchar(255) REFERENCES Patients NOT NULL,
    Vaccine varchar(255) REFERENCES Vaccines NOT NULL
);